<?php

namespace App\Http\Controllers;

use App\Models\Debt;
use Inertia\Inertia;
use Barryvdh\DomPDF\PDF;
use App\Models\Receivable;
use App\Models\Transaction;
use Illuminate\Http\Request;

class LaporanController extends Controller
{
    /**
     * Menampilkan halaman form untuk filter laporan.
     *
     * @return \Inertia\Response
     */
    public function index()
    {
        // Method ini hanya merender halaman Vue yang berisi form filter
        return Inertia::render('Keuangan/Laporan/Index');
    }

    /**
     * Membuat dan mengunduh laporan dalam format PDF.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function cetak(Request $request)
    {
        // 1. Validasi input dari form
        $request->validate([
            'tipe' => 'required|in:pemasukan,pengeluaran,utang,piutang',
            'dari_tanggal' => 'required|date',
            'sampai_tanggal' => 'required|date|after_or_equal:dari_tanggal',
        ]);

        $tipe = $request->tipe;
        $dari = $request->dari_tanggal;
        $sampai = $request->sampai_tanggal;
        $data = [];
        $viewName = 'laporan.pdf_template_transaksi'; // Default view

        // 2. Mengambil data berdasarkan tipe laporan
        switch ($tipe) {
            case 'pemasukan':
            case 'pengeluaran':
                $data = Transaction::where('tipe', $tipe)
                    ->whereBetween('tanggal', [$dari, $sampai])
                    ->with('user') // Mengambil data user
                    ->get();
                break;
            
            case 'utang':
                $data = Debt::whereBetween('tanggal_utang', [$dari, $sampai])
                    ->with('user')
                    ->get();
                $viewName = 'laporan.pdf_template_utang'; // Gunakan view khusus utang
                break;

            case 'piutang':
                $data = Receivable::whereBetween('tanggal_piutang', [$dari, $sampai])
                    ->with('user')
                    ->get();
                $viewName = 'laporan.pdf_template_piutang'; // Gunakan view khusus piutang
                break;
        }

        // 3. Membuat PDF dari data yang sudah diambil
        $pdf = app('dompdf')->loadView($viewName, [
            'data' => $data,
            'tipe' => $tipe,
            'dari' => $dari,
            'sampai' => $sampai
        ]);
        
        // 4. Memberikan nama file dan mengizinkan unduhan
        $fileName = 'laporan-' . $tipe . '-' . $dari . '_sd_' . $sampai . '.pdf';
        return $pdf->download($fileName);
    }
}