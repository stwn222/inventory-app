<!DOCTYPE html>
<html>
<head>
    <title>Laporan {{ ucfirst($tipe) }}</title>
    <style>
        body { font-family: sans-serif; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Laporan {{ ucfirst($tipe) }}</h1>
    <p>Periode: {{ $dari }} s/d {{ $sampai }}</p>
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Catatan</th>
                <th>Jumlah</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $item)
            <tr>
                <td>{{ $item->tanggal }}</td>
                <td>{{ $item->catatan }}</td>
                <td>Rp {{ number_format($item->jumlah, 2, ',', '.') }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>